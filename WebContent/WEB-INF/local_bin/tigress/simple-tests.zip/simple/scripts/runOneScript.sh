#!/bin/bash

script=$1
resultsDir=$2
xargs=$3

echo $script > /tmp/scripts.txt
find generated/programs/*/* -name \*.c > /tmp/programs.txt
base=`basename $script .sh`

/bin/rm $resultsDir/$base/*

if [[ -n $xargs ]]
then
   $xargs -a /tmp/scripts.txt -a /tmp/programs.txt scripts/runTest.sh
else
   join -t" " -j 9999 -o 1.1,2.1 /tmp/scripts.txt /tmp/programs.txt > /tmp/tests.txt
   IFS=$'\n'
   for test in `cat /tmp/tests.txt`
   do
      IFS=" "
      args=($test)
      scripts/runTest.sh ${args[0]} ${args[1]} $resultsDir 
   done
fi

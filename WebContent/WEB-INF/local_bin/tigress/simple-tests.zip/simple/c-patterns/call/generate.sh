#!/bin/bash 

/bin/rm -f *.c exe

source "../types.sh"

number=0


##################################################################
# generate C programs
##################################################################
function generate() {
   for_intTypes_do call1
   for_floatTypes_do call1
   for_intTypes_do call2
   for_floatTypes_do call2
   for_intTypes_do call3
   for_floatTypes_do call3
   for_intTypes_do call4
   for_floatTypes_do call4
   for_intTypes_do call5
   for_floatTypes_do call5
   for_intTypes_do call6
   for_floatTypes_do call6
   for_single_do indcall1
   for_single_do call7
   for_intTypes_do call8
   for_floatTypes_do call8
   for_intTypes_do call9
   for_floatTypes_do call9
   for_intTypes_do callA
   for_floatTypes_do callA
   for_intTypes_do callB
   for_floatTypes_do callB
   for_intTypes_do callC
   for_floatTypes_do callC
}

##################################################################
# main()
##################################################################
function main() {
   generate
   execute
}

##################################################################
# run
##################################################################
main
exit 0
